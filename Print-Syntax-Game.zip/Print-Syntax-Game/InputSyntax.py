class InputVariable:
  #right side syntax has to be =input()
  #left side syntax has to be a valid variable 
  def __init__(self):
      self.rsyntax="=input()"


  #---------------------Break Cases----------------------
  """generalize the functions from print syntax to be base on length of string
  make a class for it?
  swap TODO
  add TODO 
  delete TODO 
  """