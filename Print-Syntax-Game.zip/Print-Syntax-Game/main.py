from PrintSyntax import PrintSyntax

p = PrintSyntax()
p.driver()